package cilok.com.lapakjahit;

/**
 * Created by Gilbert on 4/24/2017.
 */

public class Category {
    int iconId;
    String title;
}
