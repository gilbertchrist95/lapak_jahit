package cilok.com.lapakjahit.extras;

/**
 * Created by Gilbert on 5/11/2017.
 */

public interface Constants {
    String NA = "NA";
}
