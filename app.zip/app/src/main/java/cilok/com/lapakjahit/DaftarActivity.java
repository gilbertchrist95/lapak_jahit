package cilok.com.lapakjahit;

/**
 * Created by Alhaura on 11/05/2017.
 */

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;


public class DaftarActivity extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daftar);
    }
}
