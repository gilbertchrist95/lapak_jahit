package cilok.com.lapakjahit.extras;

import android.os.Build;

/**
 * Created by Gilbert on 5/11/2017.
 */

public class Util {
    public static boolean isLollipopOrGreater() {
        return Build.VERSION.SDK_INT >= 21 ? true : false;
    }
    public static boolean isJellyBeanOrGreater(){
        return Build.VERSION.SDK_INT>=16?true:false;
    }
}
